<?php

namespace ITeam\Kashier\Security;

use ITeam\Kashier\Iframe\IframeParameter;
use ITeam\Kashier\Context\Context;

/**
 * Class Hash
 *
 * Helper class to encrypt data with api key
 *
 * @package ITeam\Kashier\Security
 */
class Hash implements ICipher
{
    private $iframeParameter;
    private $context;

    public function __construct(Context $context, IframeParameter $iframeParameter)
    {
        $this->iframeParameter = $iframeParameter;
        $this->context = $context;

    }

    /**
     * Encrypts the input text using the cipher key
     *
     * @return string
     */
    public function encrypt()
    {


        $path = '/?payment='
            . $this->context->getMerchantId()
            . '.'
            . $this->iframeParameter->getOrderId()
            . '.'
            . $this->iframeParameter->getAmount()
            . '.'
            . $this->iframeParameter->getCurrency();

        return hash_hmac('sha256', $path, $this->context->getCredential()->getApiKey(), false);
    }
}
