<?php
use ITeam\Kashier\Core\KashierConstants;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WC_Gateway_Kashier class.
 *
 * @extends WC_Payment_Gateway
 */
class WC_Gateway_Installment extends WC_Payment_Gateway_CC
{

    /**
     * @var string
     */
    public $api_key;
    /**
     * @var bool
     */
    public $testmode;
    /**
     * @var string
     */
    public $merchant_id;
    /**
     * @var string
     */
    public $color;
    /**
     * @var string
     */
    public $method;
    /**
     * @var bool
     */
    public $logging_enabled;
    /**
     * @var \ITeam\Kashier\Context\Context
     */
    public $context;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->id = 'installment';
        $this->method_title = WC_Kashier_Helper::get_localized_message('installment','payment_method_title');
        $this->method_description = sprintf(WC_Kashier_Helper::get_localized_message('installment','payment_method_description'), 'https://kashier.io/', 'https://merchant.kashier.io/en/signup');
        $this->method_public_description = WC_Kashier_Helper::get_localized_message('installment','payment_method_public_description');

        $this->has_fields = true;
        $this->supports = [
            'products',
        ];

        // Load the form fields.
        $this->init_form_fields();

        // Load the settings.
        $this->init_settings();

        // Get setting values.
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');
        $this->testmode = 'yes' === $this->get_option('testmode');
        $this->logging_enabled = 'yes' === $this->get_option('logging');
        $this->merchant_id = $this->get_option('merchant_id');
        $this->api_key = $this->testmode ? $this->get_option('test_api_key') : $this->get_option('api_key');
        $this->advanced_options = 'yes' === $this->get_option('advanced_options');
        
        if($this->advanced_options){
            if($this->get_option('enforce_egp_payment') === 'yes'){
               $this->selected_currency = 'EGP';
               $this->exchange_rate = number_format((float)$this->get_option('exchange_rate'), 2, '.', '');
            };
       }


        $this->context = new \ITeam\Kashier\Context\Context(
            $this->merchant_id,
            new \ITeam\Kashier\Auth\KashierKey($this->api_key)
        );

        $this->context->setConfig([
            'mode' => $this->testmode ? 'sandbox' : 'live',
            'log.LogEnabled' => $this->logging_enabled,
            'log.LogLevel' => $this->testmode ? 'debug' : 'info',
            'log.AdapterFactory' => WC_Kashier_Logger_Factory::class
        ]);

        // Hooks.
        add_action('wp_enqueue_scripts', [$this, 'payment_scripts']);
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('set_logged_in_cookie', [$this, 'set_cookie_on_current_request']);
        add_action('woocommerce_receipt_' . $this->id, [$this, 'kashier_receipt_page']);
        add_action('woocommerce_api_wc_gateway_kashier', [$this, 'check_response']);
        
    }

    public function admin_options()
    {
            parent::admin_options();
            $path = plugins_url('/Kashier-WooCommerce-Plugin-master/assets/js/kashier-admin.js');
            echo "<script type='text/javascript' id='kashier-admin' methodId='$this->id' src='$path'></script>";
            
    }

    /**
     * Initialise Gateway Settings Form Fields
     */
    public function init_form_fields()
    {
        $this->form_fields = require __DIR__ . '/admin/kashier-settings.php';
    }

    /**
     *
     */
    public function check_response()
    {
        $localizedErrors = WC_Kashier_Helper::get_localized_messages();

        $response = [
            'result' => 'failure',
            'redirect' => home_url()
        ];

        $order_id = wc_get_order_id_by_order_key(urldecode(wc_clean($_POST['order_key'])));
        $order = wc_get_order($order_id);

        if (is_a($order, WC_Order::class)) {
            if (strtoupper($_POST['status']) === 'SUCCESS' && isset($_POST['response']['card']['result']) && strtoupper($_POST['response']['card']['result']) === 'SUCCESS') {
                $this->_payment_success_handler($order, wc_clean($_POST['response']['transactionId']));

                $response['result'] = 'success';
                $response['redirect'] = $this->get_return_url($order);
            } else {
                // wc_add_notice($localizedErrors['installment']['please_check_card_info'], 'error');
				$message = sprintf(__('(Transaction ID: %s)', 'woocommerce-gateway-kashier'), $_POST['response']['transactionId']);
				$order->add_order_note(__('Payment Error: ') .  ' ' . $message);
				$order->update_status('failed');
                $response['redirect'] = $order->get_checkout_payment_url();
            }
        } else {
            wc_add_notice($localizedErrors['installment']['order_not_found'], 'error');
        }

        wp_send_json($response);
    }


    /**
     * @param WC_Order $order
     * @param string $transaction_id
     */
    protected function _payment_success_handler($order, $transaction_id)
    {
        $order->payment_complete($transaction_id);
        $message = sprintf(__('Kashier charge complete (Transaction ID: %s)', 'woocommerce-gateway-kashier'), $transaction_id);
        $order->add_order_note($message);

        // Remove cart.
        WC()->cart->empty_cart();
    }

    /**
     * @param $order_id
     */
    public function kashier_receipt_page($order_id)
    {
        global $woocommerce;

        $order = new WC_Order($order_id);
        $order_meta = get_post_meta($order->get_id(), '');
        $firstName =  WC_Kashier_Helper::is_wc_lt('3.0') ? $order->billing_first_name : $order->get_billing_first_name();
        $secondName =  WC_Kashier_Helper::is_wc_lt('3.0') ? $order->billing_last_name : $order->get_billing_last_name();
        $metaData = json_encode(array(
                           'OrderId' => $order_id,
                           'CustomerEmail' => $order->billing_email,
                           'CustomerName' => $firstName . $secondName,
        ));
        $mode = $this->testmode ? 'test' : 'live';
        $storeName = str_replace(' ', '-', get_bloginfo( 'name' ));
        $iframe_base_url = KashierConstants::IFRAME_BASE_URL;
        $iframeParameter = new \ITeam\Kashier\Iframe\IframeParameter();

        $iframeParameter
            ->setOrderId($order->get_id() . '-' . time())
            ->setMethod('bank_installments')
            ->setMerchantId($this->context->getMerchantId())
            ->setShopperReference((string)get_current_user_id())
            ->setDisplay(substr($lang=get_bloginfo("language"),0,2));

            
        if($this->advanced_options){
            if( ($this->get_option('enforce_egp_payment') === 'yes') && ($order->get_currency() != 'EGP') ){
                $iframeParameter
                    ->setCurrency($this->selected_currency)
                    ->setAmount(($order->get_total() * $this->exchange_rate));
            }
            else {
                $iframeParameter
                    ->setCurrency($order->get_currency())
                    ->setAmount($order->get_total());
            }
        } 
        else {
            $iframeParameter
                ->setCurrency($order->get_currency())
                ->setAmount($order->get_total());
        }

        $hash = new \ITeam\Kashier\Security\Hash($this->context, $iframeParameter);
        $iframeParameter
            ->setHash($hash->encrypt());

        ?>
        <script id="kashier-iFrame"
        src=<?php echo($iframe_base_url) . '/kashier-checkout.js' ?>
        data-amount=<?php echo($iframeParameter->getAmount()) ?>
        data-description='description'
        data-hash=<?php echo($iframeParameter->getHash()) ?>
        data-currency=<?php echo($iframeParameter->getCurrency()) ?>
        data-orderId=<?php echo($iframeParameter->getOrderId()) ?>
        data-merchantId=<?php echo($iframeParameter->getMerchantId())?>
        data-allowedMethods=<?php echo($iframeParameter->getMethod())?>
        data-store=<?php echo($storeName) ?>
        data-metaData=<?php echo($metaData) ?>
        data-mode=<?php echo($mode) ?>
        data-redirectMethod="post"
        style="display:block"
        data-type="external" 
        data-display=<?php echo($iframeParameter->getDisplay()) ?> > </script>
        <?php
    }

    /**
     * Checks if gateway should be available to use.
     */
    public function is_available()
    {
        if (is_add_payment_method_page()) {
            return false;
        }

        return parent::is_available();
    }

    /**
     * Get_icon function.
     *
     *
     *
     * @return string
     */
    public function get_icon()
    {
        $icons = $this->payment_icons();

        $icons_str = '';

        $icons_str .= isset($icons['visa']) ? $icons['visa'] : '';
        $icons_str .= isset($icons['mastercard']) ? $icons['mastercard'] : '';
        $icons_str .= isset($icons['meeza']) ? $icons['meeza'] : '';

        return apply_filters('woocommerce_gateway_icon', $icons_str, $this->id);
    }

    /**
     * All payment icons that work with Kashier. Some icons references
     * WC core icons.
     *
     * @return array
     */
    public function payment_icons()
    {
        return apply_filters(
            'wc_kashier_payment_icons',
            [
                'mastercard' => '<img src="' . WC_KASHIER_PLUGIN_URL . '/assets/images/installment.jpg" class="kashier-mastercard-icon kashier-icon" alt="Bank Installment" />',
            ]
        );
    }

    /**
     * Payment form on checkout page
     */
    public function payment_fields()
    {
        $description = $this->get_description();
        $description = !empty($description) ? $description : '';

        if ($this->testmode) {
            $description .= ' ' . __('TEST MODE ENABLED', 'woocommerce-gateway-kashier');
        }

        $description = trim($description);

        echo apply_filters('wc_kashier_description', wpautop(wp_kses_post($description)), $this->id);


        $this->elements_form();
        
        echo '<div id="secured-by-kashier-container"><img src="' . WC_KASHIER_PLUGIN_URL . '/assets/images/secured-by-kashier.png" alt="Secured by Kashier"/></div>';

        do_action('wc_kashier_cards_payment_fields', $this->id);
    }

    /**
     * Renders the Kashier elements form.
     */
    public function elements_form()
    {   
        
     
    }

    /**
     * Payment_scripts function.
     *
     * Outputs scripts used for kashier payment
     */
    public function payment_scripts()
    {
        global $woocommerce;

        if (!is_product() && !is_cart() && !is_checkout() && !isset($_GET['pay_for_order']) && !is_add_payment_method_page() && !isset($_GET['change_payment_method'])) { // wpcs: csrf ok.
            return;
        }

        // If Kashier is not enabled bail.
        if ('no' === $this->enabled) {
            return;
        }

        // If keys are not set bail.
        if (!$this->are_keys_set()) {
            WC_Kashier_Logger::addLog('Keys are not set correctly.');
            return;
        }

        $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '';

        wp_register_style('kashier_styles', plugins_url('assets/css/kashier-styles.css', WC_KASHIER_MAIN_FILE), [], WC_KASHIER_VERSION);
        wp_enqueue_style('kashier_styles');


        wp_register_script('woocommerce_kashier_iframe', plugins_url('assets/js/kashier-iframe' . $suffix . '.js', WC_KASHIER_MAIN_FILE), ['jquery-payment'], WC_KASHIER_VERSION, true);

        $kashier_params = [];

   
        $kashier_params['is_order_pay_page'] = is_wc_endpoint_url('order-pay');
        
        $kashier_params['callback_url'] = add_query_arg('wc-api', 'WC_Gateway_Kashier', home_url('/'));

        if ($kashier_params['is_order_pay_page']) {
            $order_id = wc_get_order_id_by_order_key(urldecode($_GET['key']));
            $order = wc_get_order($order_id);
            if (is_a($order, WC_Order::class)) {
                $kashier_params['billing_first_name'] = WC_Kashier_Helper::is_wc_lt('3.0') ? $order->billing_first_name : $order->get_billing_first_name();
                $kashier_params['billing_last_name'] = WC_Kashier_Helper::is_wc_lt('3.0') ? $order->billing_last_name : $order->get_billing_last_name();

                $kashier_params['current_order_key'] = urldecode($_GET['key']);
                $kashier_params['return_url'] = esc_url_raw($this->get_return_url($order));
                $kashier_params['callback_url'] = add_query_arg('wc-api', 'WC_Gateway_Kashier', home_url('/'));
            }
        }

        // Merge localized messages to be use in JS.
        $kashier_params = array_merge($kashier_params, WC_Kashier_Helper::get_localized_messages()['installment']);
        $kashier_params = apply_filters('wc_kashier_params', $kashier_params);

        wp_localize_script('woocommerce_kashier_iframe', 'wc_kashier_params', $kashier_params);

        wp_enqueue_script('woocommerce_kashier_iframe');
    }

    /**
     * Checks if keys are set.
     *
     *
     * @return bool
     */
    public function are_keys_set()
    {
        if (empty($this->api_key)) {
            return false;
        }

        return true;
    }


    /**
     * Process the payment
     *
     * @param int $order_id Reference.
     * @param bool $retry Should we retry on fail.
     * @param bool $force_save_source Force save the payment source.
     * @param bool $previous_error Any error message from previous request.
     *
     * @return array
     * @throws \ITeam\Kashier\Exception\KashierConfigurationException
     * @throws \ITeam\Kashier\Exception\KashierConnectionException
     */
    public function process_payment($order_id, $retry = true, $force_save_source = false, $previous_error = false)
    {
        $order = wc_get_order($order_id);

        $redirectUrl = $this->get_return_url($order);
        try {

            if (0 >= $order->get_total()) {
                return $this->complete_free_order($order);
            }

            // This will throw exception if not valid.
            $this->validate_minimum_order_amount($order);

            WC_Kashier_Logger::addLog("Info: Begin processing payment for order $order_id for the amount of {$order->get_total()}");

            WC_Kashier_Logger::addLog('Processing response: ' . print_r($response, true));


                $redirectUrl = $order->get_checkout_payment_url(true);


            if (is_callable([$order, 'save'])) {
                $order->save();
            }

            return [
                'result' => 'success',
                'redirect' => $redirectUrl,
            ];

        } catch (Exception $e) {
            wc_add_notice($e->getLocalizedMessage(), 'error');
            WC_Kashier_Logger::addLog('Error: ' . $e->getMessage());

            do_action('wc_gateway_kashier_process_payment_error', $e, $order);

            $order->update_status('failed');

            return [
                'result' => 'failure',
                'redirect' => '',
            ];
        }
    }
       
    /**
     * Completes an order without a positive value.
     *
     *
     * @param WC_Order $order The order to complete.
     * @return array Redirection data for `process_payment`.
     */
    public function complete_free_order($order)
    {
        $order->payment_complete();

        // Remove cart.
        WC()->cart->empty_cart();

        // Return thank you page redirect.
        return [
            'result' => 'success',
            'redirect' => $this->get_return_url($order),
        ];
    }

    /**
     * Validates that the order meets the minimum order amount
     * set by Kashier.
     *
     * @param object $order
     * @throws WC_Kashier_Exception
     */
    public function validate_minimum_order_amount($order)
    {
        if ($order->get_total() * 100 < WC_Kashier_Helper::get_minimum_amount()) {
            throw new WC_Kashier_Exception('Did not meet minimum amount', sprintf(WC_Kashier_Helper::get_localized_message('installment','minimum_amount_error'), wc_price(WC_Kashier_Helper::get_minimum_amount() / 100)));
        }
    }

    /**
     * Proceed with current request using new login session (to ensure consistent nonce).
     */
    public function set_cookie_on_current_request($cookie)
    {
        $_COOKIE[LOGGED_IN_COOKIE] = $cookie;
    }

   
}