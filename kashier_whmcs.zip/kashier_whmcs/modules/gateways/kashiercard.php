<?php

require_once dirname(__FILE__).'/kashier/Kashier.php';

use Illuminate\Database\Capsule\Manager as Capsule;
/**
 * WHMCS Sample Payment Gateway Module
 *
 * Payment Gateway modules allow you to integrate payment solutions with the
 * WHMCS platform.
 *
 * This sample file demonstrates how a payment gateway module for WHMCS should
 * be structured and all supported functionality it can contain.
 *
 * Within the module itself, all functions must be prefixed with the module
 * filename, followed by an underscore, and then the function name. For this
 * example file, the filename is "gatewaymodule" and therefore all functions
 * begin "gatewaymodule_".
 *
 * If your module or third party API does not support a given function, you
 * should not define that function within your module. Only the _config
 * function is required.
 *
 * For more information, please refer to the online documentation.
 *
 * @see https://developers.whmcs.com/payment-gateways/
 *
 * @copyright Copyright (c) WHMCS Limited 2017
 * @license http://www.whmcs.com/license/ WHMCS Eula
 */

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}


/**
 * Define module related meta data.
 *
 * Values returned here are used to determine module related capabilities and
 * settings.
 *
 * @see https://developers.whmcs.com/payment-gateways/meta-data-params/
 *
 * @return array
 */
function kashiercard_MetaData()
{
    return array(
        'DisplayName' => 'Kashier Card Payment Gateway Module',
        'APIVersion' => '2', 
        'DisableLocalCreditCardInput' => true,
        'TokenisedStorage' => false,
    );
}

/**
 * Define gateway configuration options.
 *
 * The fields you define here determine the configuration options that are
 * presented to administrator users when activating and configuring your
 * payment gateway module for use.
 *
 * Supported field types include:
 * * text
 * * password
 * * yesno
 * * dropdown
 * * radio
 * * textarea
 *
 * Examples of each field type and their possible configuration parameters are
 * provided in the sample function below.
 *
 * @return array
 */
function kashiercard_config()
{
    try{
        if (!Capsule::schema()->hasTable('kashier_orders')) {
            Capsule::schema()->create(
                'kashier_orders',
                function ($table) {
                    /* @var \Illuminate\Database\Schema\Blueprint $table */
                    $table->increments('id');
                    $table->integer('order_id');
                    $table->integer('invoice_id');
                    $table->text('data');
                    $table->index('invoice_id');
                }
            );
        }
    }catch( Exception $e){
    }
    $kashier = new Kashier();
    $config = $kashier->getConfig();
    if (isset($config['FriendlyName']['Value'])) {
        $config['FriendlyName']['Value'] = 'Kashier Card';
    }
    return $config;
}

/**
 * Payment link.
 *
 * Required by third party payment gateway modules only.
 *
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 *
 * @param array $params Payment Gateway Module Parameters
 *
 * @see http://docs.whmcs.com/Payment_Gateway_Module_Parameters
 *
 * @return string
 */
function kashiercard_link($params)
{
    logTransaction($params['paymentmethod'], json_encode($params), 'params json: ');
    $kashier = new Kashier();
    $data = $kashier->getData($params, 'card');

    $mode = $kashier->getMode($params['test_mode']);

    logTransaction($params['paymentmethod'], $base_url, 'url is');
    logTransaction($params['paymentmethod'], json_encode($data), 'data is ');

    //find row
    $row = Capsule::table('kashier_orders')->where('invoice_id', $params['invoiceid'])->first();

    if (!$row) {

            $redirect_url='https://checkout.kashier.io/?merchantId='.$params['merchant_id'].'&allowedMethods='.$data['method'].'&orderId='.$data['order_id'].'&mode='.$mode.'&amount='.$data['amount'].'&currency='.$data['currency'].'&hash='.$data['hash'].'&merchantRedirect='.$data['return_url'].'&serverWebhook='.$data['callback_url'].'&redirectMethod=get'.'&display=en&metaData='.$data['meta_data'];     

            //insert
            Capsule::table('kashier_orders')->insert(['order_id' => 0, 'invoice_id' => $params['invoiceid'], 'data' => $redirect_url]);
            return '';
       
    }

    $htmlOutput = '<a href="' . $row->data . '" >Pay Now</a>';


    return $htmlOutput;

}
